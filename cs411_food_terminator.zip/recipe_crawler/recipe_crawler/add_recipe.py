# -*- coding: utf-8 -*-
import mysql.connector
from decimal import Decimal
import json
import progressbar

db = mysql.connector.connect(
    host="172.22.148.182",
    user="test",
    passwd="13579",
    database="food_terminator"
)
cursor = db.cursor(buffered=True)


def get_uid(author_name):
    sql = "SELECT uid FROM User WHERE username='{}'".format(author_name)
    cursor.execute(sql)
    result = cursor.fetchall()
    if len(result) > 0:
        return result[0][0]
    else:
        email = author_name.replace(" ", "_") + "@gmail.com"
        password = "12345678"
        sql = "INSERT INTO User (username, email, password) VALUES (%s, %s, %s)"
        val = (author_name, email, password)
        cursor.execute(sql, val)
        db.commit()
        sql = "SELECT LAST_INSERT_ID()"
        # sql = "SELECT uid FROM User WHERE username='{}'".format(author_name)
        cursor.execute(sql)
        return cursor.fetchall()[0][0]


def insert_recipe(uid, data):
    image = recipe["image"]
    name = recipe["name"]
    instruction = recipe["instruction"]
    duration = recipe["totalTime"]
    cuisine = recipe["cuisine"]
    serving = recipe["serving"]
    category = recipe["category"]
    protein = recipe["nutrition"]["proteinContent"]
    calories = recipe["nutrition"]["calories"]
    fat = recipe["nutrition"]["fatContent"]
    carbohydrate = recipe["nutrition"]["carbohydrateContent"]
    fiber = recipe["nutrition"]["fiberContent"]
    sodium = recipe["nutrition"]["sodiumContent"]
    sugar = recipe["nutrition"]["sugarContent"]

    sql = """INSERT INTO Recipe (image, name, instruction, duration, cuisine, serving, 
            category, protein, calories, fat, carbohydrate, fiber, sodium, sugar, uid) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""

    val = (image, name, instruction, duration, cuisine, serving, category, protein, calories, fat, carbohydrate, fiber, sodium, sugar, uid)
    
    cursor.execute(sql, val)
    db.commit()

    sql = "SELECT LAST_INSERT_ID()"
    # sql = "SELECT rid FROM Recipe WHERE image='{}' AND uid={} AND name='{}'".format(image, uid, name)
    cursor.execute(sql)
    return cursor.fetchall()[0][0]


def insert_ingredient(rid, ingredient_name, amount, unit):
    sql = "INSERT INTO Ingredient (rid, name, amount, unit) VALUES (%s, %s, %s, %s)"
    val = (rid, ingredient_name, amount, unit)
    cursor.execute(sql, val)
    db.commit()


def insert_tags(rid, tag_name):
    sql = "INSERT INTO Tag (rid, name) VALUES (%s, %s)"
    val = (rid, tag_name)
    try:
        cursor.execute(sql, val)
        db.commit()
    except:
        return


    

if  __name__ == "__main__":
    json_file = open("recipe_data.json", "r")
    recipes = json.load(json_file)
    json_file.close()

    num_recipe = len(recipes)
    bar = progressbar.ProgressBar(maxval=num_recipe, widgets=[progressbar.Bar('=', '[', ']'), ' ', progressbar.Percentage()])
    bar.start()

    for idx in range(num_recipe):
        bar.update(idx)
        recipe = recipes[idx]
        ingredients = recipe["ingredients"]
        author_name = recipe["author"]

        author_id = get_uid(author_name)
        rid = insert_recipe(author_id, recipe)

        for (ingredient_name, amount) in recipe["ingredients"].items():
            insert_ingredient(rid, ingredient_name, amount["amount"], amount["unit"])

        tags = recipe["tags"]
        for tag in tags:
            if tag != "":
                insert_tags(rid, tag)

    bar.finish()
