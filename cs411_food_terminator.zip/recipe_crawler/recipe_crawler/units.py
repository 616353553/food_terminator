import json

if __name__ == "__main__":
    # read from recipe_data_raw.json
    json_file = open("recipe_data.json", "r")
    recipes = json.load(json_file)
    json_file.close()

    # calculation
    units = {}
    for recipe in recipes:
        ingredient_list = recipe["ingredients"]
        for ingredient, amount in ingredient_list.items():
            unit = amount["unit"]
            if unit in units:
                units[unit] += 1
            else:
                units[unit] = 1

    # write ingredients data
    json_file = open("units.json", "w")
    units = sorted(units.items(), key=lambda kv: kv[1])
    json_file.write(json.dumps(units, indent=2))
    json_file.close()
