from urllib.request import urlopen as uReq
from bs4 import BeautifulSoup as soup
from selenium import webdriver
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
import logging
import json
import threading


url = "https://www.bigoven.com/recipes/course"
base_url = "https://www.bigoven.com/"
threads_count = 16

logging.basicConfig(filename="recipe_crawler.log", level=logging.WARNING,
                    format="%(asctime)s:%(levelname)s:%(message)s")

recipes = list()
recipe_urls = list()
# recipe_urls = ["https://www.bigoven.com/recipe/baked-garlic/217567", 
#                 "https://www.bigoven.com/recipe/antipasto-platter/397378",
#                 "https://www.bigoven.com/recipe/black-bean-hummus/1020672",
#                 "https://www.bigoven.com/recipe/zucchini-artichoke-hummus-pillows/734712",
#                 "https://www.bigoven.com/recipe/real-mans-hummus/250980"]

garbage_urls = ["https://www.bigoven.com/recipe/sformatini-di-carciofi-con-salsa-al-parmigiano/187721",
                "https://www.bigoven.com/recipe/pat-de-aceitunas-negras-y-anchoas/405895"]


def get_page_soup(page_url, driver):
    page_soup = None
    try:
        driver.get(page_url)
        page_html = driver.page_source
        page_soup = soup(page_html, "html.parser")
    except:
        logging.error("Cannot retrieve url({})".format(page_url))
    finally:
        return page_soup
        

def crawl_recipe_data(recipe_url, driver):
    page_soup = get_page_soup(recipe_url, driver)
    if page_soup is None:
        logging.error("Cannot get page soup({})".format(recipe_url))
        return None
    recipe_data = {"url": recipe_url, "ingredients": dict()}
    script_elem = page_soup.find("script", {"type": "application/ld+json"})
    if script_elem is None:
        logging.warn("Script data not found({})".format(recipe_url))
        return None
    else:
        try:
            script_data = json.loads(script_elem.text, strict=False)
        except ValueError as e:
            logging.error("Recipe json bad format({})".format(recipe_url))
            return None
        recipe_data["name"] = script_data["name"]
        recipe_data["instruction"] = script_data["recipeInstructions"][0]
        recipe_data["image"] = script_data["image"]
        recipe_data["totalTime"] = script_data["totalTime"]
        recipe_data["cuisine"] = script_data["recipeCuisine"]
        recipe_data["category"] = script_data["recipeCategory"]
        recipe_data["author"] = script_data["author"]
        recipe_data["serving"] = script_data["recipeYield"]
        recipe_data["nutrition"] = {}
        recipe_data["nutrition"]["calories"] = script_data["nutrition"]["calories"]
        recipe_data["nutrition"]["fatContent"] = script_data["nutrition"]["fatContent"]
        recipe_data["nutrition"]["carbohydrateContent"] = script_data["nutrition"]["carbohydrateContent"]
        recipe_data["nutrition"]["cholesterolContent"] = script_data["nutrition"]["cholesterolContent"]
        recipe_data["nutrition"]["fiberContent"] = script_data["nutrition"]["fiberContent"]
        recipe_data["nutrition"]["proteinContent"] = script_data["nutrition"]["proteinContent"]
        recipe_data["nutrition"]["saturatedFatContent"] = script_data["nutrition"]["saturatedFatContent"]
        recipe_data["nutrition"]["sodiumContent"] = script_data["nutrition"]["sodiumContent"]
        recipe_data["nutrition"]["sugarContent"] = script_data["nutrition"]["sugarContent"]
        recipe_data["nutrition"]["transFatContent"] = script_data["nutrition"]["transFatContent"]
        recipe_data["keywords"] = script_data["keywords"]

        # keywords = script_data["keywords"].split(",")
        # for idx, keyword in enumerate(keywords):
        #     keywords[idx] = keyword.lstrip()
        #     if keywords[idx] in tags:
        #         tags[keywords[idx]] += 1
        #     else:
        #         tags[keywords[idx]] = 1
        # recipe_data["tags"] = keywords

    recipe_container = page_soup.find("div", {"class": "recipe-container modern"})
    if recipe_container is None:
        logging.error("Recipe container not found({})".format(recipe_url))
        return None

    # crawling ingredients data
    ingredient_list = recipe_container.find("ul", {"class": "ingredients-list"})
    if ingredient_list is None:
        logging.error("Ingredient list not found({})".format(recipe_url))
        return None
    ingredient_elements = ingredient_list.find_all("li")
    for ingredient_element in ingredient_elements:
        amount_element = ingredient_element.find("span", {"class": "amount"})
        if amount_element is None:
            continue
        ingredient_amount = amount_element.text.lower()
        if ingredient_amount == " ":
            continue
        name_element = ingredient_element.find("span", {"class" : "name"})
        if name_element is None:
            continue
        ingredient_name = name_element.text.lower()
        name_reference = name_element. find("a", {"class": "glosslink"})
        if name_reference is not None:
            ingredient_name = name_reference.text.lower()
        recipe_data["ingredients"][ingredient_name] = ingredient_amount
    return recipe_data


def crawl_recipes(start_index, end_index, driver, result):
    for i in range(start_index, end_index):
        recipe_url = recipe_urls[i]
        recipe_data = crawl_recipe_data(recipe_url, driver)
        if recipe_data is None:
            continue
        result.append(recipe_data)


if __name__ == "__main__":
    # read recipe urls from json file
    json_file = open("recipe_urls.json", "r")
    recipe_urls = json.load(json_file)
    json_file.close()

    # multi-thread crawling
    threads = list()
    task_count = len(recipe_urls) // threads_count
    thread_result = [list() for i in range(threads_count)]
    drivers = list()
    for thread_idx in range(threads_count):
        drivers.append(webdriver.Firefox(executable_path=r"/Users/bainingshuo/Desktop/recipe_crawler/geckodriver"))
        start_idx = thread_idx * task_count
        if thread_idx == threads_count - 1:
            new_thread = threading.Thread(target=crawl_recipes, args=(start_idx, len(recipe_urls), drivers[thread_idx], thread_result[thread_idx]))
        else:
            new_thread = threading.Thread(target=crawl_recipes, args=(start_idx, start_idx + task_count, drivers[thread_idx], thread_result[thread_idx]))
        threads.append(new_thread)
        threads[thread_idx].start()

    for thread_idx in range(threads_count):
        threads[thread_idx].join()
        recipes.extend(thread_result[thread_idx])
    
    # single thread carwling
    # for recipe_url in recipe_urls:
    #     recipe_data = crawl_recipe_data(recipe_url, driver)
    #     if recipe_data is None:
    #         continue
    #     recipes.append(recipe_data)
    
    json_file = open("recipe_data_raw.json", "w")
    json_file.write(json.dumps(recipes, indent=2))
    json_file.close()