import json

if __name__ == "__main__":
    # read from recipe_data_raw.json
    json_file = open("recipe_data.json", "r")
    recipes = json.load(json_file)
    json_file.close()

    # calculation
    cuisines = {}
    for recipe in recipes:
        cuisine = recipe["cuisine"]
        if cuisine in cuisines:
            cuisines[cuisine] += 1
        else:
            cuisines[cuisine] = 1

    # write ingredients data
    json_file = open("cuisines.json", "w")
    cuisines = sorted(cuisines.items(), key=lambda kv: kv[1])
    json_file.write(json.dumps(cuisines, indent=2))
    json_file.close()