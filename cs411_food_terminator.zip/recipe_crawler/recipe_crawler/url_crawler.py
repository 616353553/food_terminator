from urllib.request import urlopen as uReq
from bs4 import BeautifulSoup as soup
from selenium import webdriver
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
import logging
import json
import threading

url = "https://www.bigoven.com/recipes/course"
base_url = "https://www.bigoven.com/"
max_recipe_count = 100

logging.basicConfig(filename="url_crawler.log", level=logging.WARNING,
                    format="%(asctime)s:%(levelname)s:%(message)s")

courses = ["appetizers", "bread", "breakfast", "desserts", "drinks", "main-dish",
            "salad", "side-dish", "soups-stews-and-chili", "marinades-and-sauces"]

sub_courses = list()
recipe_urls = list()


def get_page_soup(page_url, driver):
    page_soup = None
    try:
        driver.get(page_url)
        page_html = driver.page_source
        page_soup = soup(page_html, "html.parser")
    except:
        logging.error("Cannot retrieve url({})".format(page_url))
    finally:
        return page_soup

    
def crawl_sub_courses(course_url, driver):
    page_soup = get_page_soup(course_url, driver)
    sub_courses = list()
    if page_soup is None:
        return sub_courses
    recipe_container = page_soup.find("div", {"id": "recipesContainer"})
    if recipe_container is None:
        logging.error("Recipe container not found({})".format(course_url))
        return sub_courses
    else:
        sub_course_divs = recipe_container.find_all("div", {"class": "thumblg category"})
        for sub_course_div in sub_course_divs:
            sub_course = sub_course_div.find("a")["href"]
            sub_courses.append(sub_course)
        return sub_courses


def crawl_recipe_urls_from_sub_course(sub_course_url, driver):
    page_soup = get_page_soup(sub_course_url, driver)
    urls = list()
    if page_soup is None:
        return urls
    result_container = page_soup.find("div", {"id": "resultContainer"})
    if result_container is None:
        logging.error("Result container not found({})".format(sub_course_url))
        return urls
    else:
        recipe_divs = result_container.find_all("div", {"class": "recipe-tile-full"})
        for recipe_div in recipe_divs:
            recipe = recipe_div["data-url"]
            urls.append(recipe)
        return urls



def crawl_recipe_urls_from_course(course_name, driver, result):
    course_url = base_url + "recipes/" + course_name
    print(course_url)
    sub_courses = crawl_sub_courses(course_url, driver)
    for sub_course in sub_courses:
        count = 0
        page_number = 1
        while count < max_recipe_count:
            urls = crawl_recipe_urls_from_sub_course(base_url + sub_course + "/page/{}".format(page_number), driver)
            if len(urls) == 0:
                break
            result.extend(urls)
            count += len(urls)
            page_number += 1


if __name__ == "__main__":
    # multi-thread crawling
    threads = list()
    thread_result = [list() for i in range(len(courses))]
    drivers = list()
    for thread_idx in range(len(courses)):
        drivers.append(webdriver.Firefox(executable_path=r"/Users/bainingshuo/Desktop/recipe_crawler/geckodriver"))
        course_name = courses[thread_idx]
        new_thread = threading.Thread(target=crawl_recipe_urls_from_course, args=(course_name, drivers[thread_idx], thread_result[thread_idx]))
        threads.append(new_thread)
        threads[thread_idx].start()

    for thread_idx in range(len(courses)):
        threads[thread_idx].join()
        recipe_urls.extend(thread_result[thread_idx])


    # single-thread crawling
    # driver = webdriver.Firefox(executable_path=r"/Users/bainingshuo/Desktop/recipe_crawler/geckodriver")
    # for course in courses:
    #     sub_courses.extend(crawl_sub_courses(base_url + "recipes/" + course, driver))
    # for sub_course in sub_courses:
    #     count = 0
    #     page_number = 1
    #     while count < max_recipe_count:
    #         urls = crawl_recipe_urls_from_sub_course(base_url + sub_course + "/page/{}".format(page_number), driver)
    #         if len(urls) == 0:
    #             break
    #         recipe_urls.extend(urls)
    #         count += len(urls)
    #         page_number += 1
    
    # write recipe urls to json file
    json_file = open("recipe_urls.json", "w")
    json_file.write(json.dumps(recipe_urls, indent=2))
    json_file.close()
    print("num of recipe urls: {}".format(len(recipe_urls)))