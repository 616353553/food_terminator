import json

def nutrition_to_double(nutrition_str):
    elems = nutrition_str.split(" ")
    if elems[1] == "mg":
        val = float(elems[0]) / 1000
    elif elems[1] == "kg":
        val = float(elems[0]) * 1000
    else:
        val = float(elems[0])
    return val

def amount_to_double(amount_str):
    amount_str = amount_str.replace("+", " ")
    amount_str = amount_str.replace("*", "")
    if amount_str == "":
        amount = 1
    elif " " in amount_str:
        parts = amount_str.split(" ")
        amount = (amount_to_double(parts[0]) + amount_to_double(parts[-1]))/2
    elif "-" in amount_str:
        parts = amount_str.split("-")
        amount = (amount_to_double(parts[0]) + amount_to_double(parts[-1]))/2
    elif "/" in amount_str:
        parts = amount_str.split("/")
        if len(parts) > 1:
            if parts[0] == "":
                parts[0] = "1.0"
            elif parts[-1] == "":
                parts[-1] = "1.0"
            try:
                amount = float(parts[0])/float(parts[-1])
            except:
                amount = 1.0
        else:
            amount = float(parts[0])
    else:
        try:
            amount = float(amount_str)
        except:
            amount = 1
    return round(amount, 2)

def parse_cuisine(cuisine):
    if cuisine == "not set":
        return "other"
    elif "spa" in cuisine:
        return "spain"
    elif "cajun" in cuisine:
        return "cajun"
    elif "japan" in cuisine:
        return "japan"
    elif "greek" in cuisine:
        return "greek"
    elif "afghan" in cuisine:
        return "afghanistan"
    elif "egypt" in cuisine:
        return "egypt"
    elif "swiss" in cuisine:
        return "switzerland"
    elif "danish" in cuisine:
        return "denmark"
    elif "german" in cuisine:
        return "germany"
    elif "mediter" in cuisine:
        return "mediterranean"
    elif "scandi" in cuisine:
        return "scandinavian"
    elif "southern" in cuisine:
        return "southern"
    elif "ital" in cuisine:
        return "italy"
    elif "asia" in cuisine:
        return "asia"
    elif "thai" in cuisine:
        return "thailand"
    elif "philippine" in cuisine:
        return "philippine"
    elif "india" in cuisine:
        return "india"
    elif "chinese" in cuisine:
        return "china"
    elif "french" in cuisine:
        return "france"
    elif "hawaiian" in cuisine:
        return "hawaii"
    elif "latin" in cuisine:
        return "latin"
    elif "mex" in cuisine:
        return "mexico"
    elif "austrian" in cuisine:
        return "austria"
    elif "austr" in cuisine:
        return "austrilia"
    elif "irish" in cuisine:
        return "ireland"
    elif "caribbean" in cuisine:
        return "caribbean"
    elif "polish" in cuisine:
        return "poland"
    elif "euro" in cuisine:
        return "europe"
    elif "cubban" in cuisine:
        return "cuba"
    elif "canad" in cuisine:
        return "canada"
    elif "jewish" in cuisine:
        return "jewish"
    elif "isr" in cuisine:
        return "israel"
    elif "english" in cuisine:
        return "britain"
    elif "british" in cuisine:
        return "britain"
    elif "africa" in cuisine:
        return "africa"
    elif "brazi" in cuisine:
        return "brazil"
    elif "pana" in cuisine:
        return "panama"
    elif "russ" in cuisine:
        return "russia"
    elif "amer" in cuisine:
        return "america"
    return "other"


def parse_unit(unit):
    if unit == "":
        return "unit"
    elif "pound" in unit:
        return "pound"
    elif "tspn" in unit:
        return "tablespoon"
    elif "cup" in unit:
        return "cup"
    elif "teaspoon" in unit:
        return "teaspoon"
    elif "inch" in unit:
        return "inch"
    elif "tbsp" in unit:
        return "tablespoon"
    elif "ts" in unit:
        return "tablespoon"
    elif "box" in unit:
        return "box"
    elif "ounce" in unit:
        return "ounce"
    elif "once" in unit:
        return "ounce"
    elif "oz" in unit:
        return "ounce"
    elif "gallon" in unit:
        return "gallon"
    elif "gram" in unit:
        return "gram"
    elif "tablespoon" in unit:
        return "tablespoon"
    elif "clove" in unit:
        return "clove"
    elif "pack" in unit:
        return "package"
    elif "pk" in unit:
        return "package"
    elif "piece" in unit:
        return "piece"
    elif "lb" in unit:
        return "pound"
    elif "strip" in unit:
        return "strip"
    elif "can" in unit:
        return "can"
    elif "tin" in unit:
        return "can"
    elif "tb" in unit:
        return "tablespoon"
    elif "jar" in unit:
        return "jar"
    elif "slice" in unit:
        return "slice"
    elif "ml" in unit:
        return "milliliter"
    elif "milliliter" in unit:
        return "milliliter"
    elif "stalk" in unit:
        return "stalk"
    elif "small" in unit:
        return "small"
    elif "medium" in unit:
        return "medium"
    elif "med" in unit:
        return "medium"
    elif "large" in unit:
        return "large"
    elif "cm" in unit:
        return "centimeter"
    elif "mililiter" in unit:
        return "milliliter"
    elif "loaf" in unit:
        return "loaf"
    elif "quart" in unit:
        return "quart"
    elif "bottle" in unit:
        return "bottle"
    elif "drop" in unit:
        return "drop"
    elif "cube" in unit:
        return "cube"
    elif "envelope" in unit:
        return "envelope"
    elif "sprig" in unit:
        return "sprig"
    elif "spring" in unit:
        return "sprig"
    elif "stem" in unit:
        return "stem"
    elif "whole" in unit:
        return "whole"
    elif "scoop" in unit:
        return "tablespoon"
    elif "container" in unit:
        return "container"
    elif "leaf" in unit:
        return "leaf"
    elif "leaves" in unit:
        return "leaf"
    elif "pint" in unit:
        return "pint"
    elif "bag" in unit:
        return "bag"
    elif "stick" in unit:
        return "stick"
    else:
        parts = unit.split()
        if "g" in parts:
            return "gram"
        elif "kg" in parts:
            return "kilogram"
        elif "kgs" in parts:
            return "kilogram"
        elif "c" in parts:
            return "cup"
    return "unit"


if __name__ == "__main__":
    # read from recipe_data_raw.json
    json_file = open("recipe_data_raw.json", "r")
    recipes = json.load(json_file)
    json_file.close()

    # calculation
    new_recipes = []
    for recipe in recipes:
        # split ingredient amount and unit
        ingredient_list = recipe["ingredients"]
        new_ingredient_list = {}
        for ingredient, amount in ingredient_list.items():
            if ingredient != "":
                parts = amount.split(" ", 1)
                new_ingredient_list[ingredient] = {"amount": amount_to_double(parts[0]), "unit": parse_unit(parts[1])}
        recipe["ingredients"] = new_ingredient_list
        # serving
        recipe["serving"] = int(float(recipe["serving"]))
        if recipe["serving"] == 0:
            recipe["serving"] = 1
        # cuisine
        recipe["cuisine"] = parse_cuisine(recipe["cuisine"].lower())
        # category
        recipe["category"] = recipe["category"].lower()
        # nutrition
        nutrition_list = recipe["nutrition"]
        new_nutrition_list = {}
        for name, value in nutrition_list.items():
            new_nutrition_list[name] = nutrition_to_double(value)
        recipe["nutrition"] = new_nutrition_list
        # tags
        keywords = recipe["keywords"].split(",")
        tags = []
        for tag in keywords:
            tags.append(tag.strip())
        recipe.pop("keywords", None)
        recipe["tags"] = tags
        new_recipes.append(recipe)

    # write ingredients data
    json_file = open("recipe_data.json", "w")
    json_file.write(json.dumps(new_recipes, indent=2))
    json_file.close()
